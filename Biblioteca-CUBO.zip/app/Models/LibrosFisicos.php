<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model; // Asegúrate de importar Eloquent

class LibrosFisicos extends Model
{
    // Aquí puedes agregar tus relaciones, atributos y métodos específicos del modelo
}
